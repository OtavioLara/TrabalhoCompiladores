package main;

abstract public class IToken {
	protected String lexema;
	protected int linha;
}
